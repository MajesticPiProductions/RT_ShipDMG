import os
import cgi
import urllib
import random
import csv

import jinja2
import webapp2

from google.appengine.ext import ndb

class Result(ndb.Model):
    average_mc = ndb.FloatProperty()
    average_la = ndb.FloatProperty()
    average_marc = ndb.FloatProperty()
    armour = ndb.IntegerProperty()
    
JINJA_ENVIRONMENT = jinja2.Environment(
    loader=jinja2.FileSystemLoader(os.path.dirname(__file__)),
    extensions=['jinja2.ext.autoescape'],
    autoescape=True)

def random_roll(die_max=10):
        return int(random.random() * die_max + 1)

def sum_of_multiple_rolls(nr_of_die, die_max=10):
    return sum([random_roll(die_max) for i in range(nr_of_die)])
            
def ToHit(BS):
    Degrees = 0
    tohit = random_roll(100)
    if (tohit <= BS):
        hit = BS - tohit
        Degrees = (hit - hit % 10 + 10) / 10
    return int(Degrees);
    
def DMG_mc(dmg, deg, arm):
    sum = sum_of_multiple_rolls(deg)+deg*dmg-arm
    if (sum < 0):
        sum = 0
    return sum;
    
def DMG_la(dmg, deg, arm):
    sum = sum_of_multiple_rolls(deg)+deg*dmg
    if (sum < 0):
        sum = 0
    return sum;
        
def DMG_marc(dmg, deg, arm):
    total = 0
    sum = 0
    while (deg > 0):
        deg -= 1
        tmp = random_roll(10) + dmg - arm + 12
        if (tmp > 0):
            sum += tmp
    return sum;
        
class MainPage(webapp2.RequestHandler):

    def get(self):
        
        path_to_Cannon_file = "./Weapons.txt"
        cannons_csv = csv.DictReader(open(path_to_Cannon_file, "r"), delimiter=";")
        cannons = {}
        item_counter = 1
        for cannon in cannons_csv:
            cannons[item_counter] = cannon
            item_counter += 1
        
        test = 'Hiiii'
        template_values = {
            'test': test,
            'cannons': cannons,
            'cannon': cannon,
        }

        template = JINJA_ENVIRONMENT.get_template('index.html')
        self.response.write(template.render(template_values))
    
class CalcPage(webapp2.RequestHandler):

    def post(self):
        BS = int(self.request.get('BS'))
        choice = int(self.request.get('choice'))
        
        path_to_Cannon_file = "./Weapons.txt"
        cannons_csv = csv.DictReader(open(path_to_Cannon_file, "r"), delimiter=";")
        cannons = {}
        item_counter = 1
        for cannon in cannons_csv:
            cannons[item_counter] = cannon
            item_counter += 1
            
        chosen_cannon = cannons[choice]
        if (chosen_cannon['Type'] == 'MC'): chosen_type = 'Macro-Cannon'
        if (chosen_cannon['Type'] == 'LA'): chosen_type = 'Lance'
        weapon = str(chosen_cannon['Name'])+ '-' + chosen_type + '\tStrength: ' + str(chosen_cannon['Strength']) + '\tDamage: 1d10+' + str(chosen_cannon['DamageBonus'])
        
        
        armour = 12
        dmg_bonus = int(chosen_cannon['DamageBonus'])
        while (armour < 21):
            count = 0.0
            total_dmg_mc = 0.0
            total_dmg_la = 0.0
            total_dmg_marc = 0.0
            while (count < 10000):
                count += 1
                deg = ToHit(BS)
                if (chosen_cannon['Type'] == 'MC'):
                    total_dmg_mc += DMG_mc(dmg_bonus, deg, armour)
                    total_dmg_marc += DMG_marc(dmg_bonus, deg, armour)
                if (chosen_cannon['Type'] == 'LA'):
                    total_dmg_la += DMG_la(dmg_bonus, deg, armour)
            if (chosen_cannon['Type'] == 'MC'):
                result = Result(parent=ndb.Key("armour", armour), average_mc = total_dmg_mc/count, average_marc = total_dmg_marc/count, armour = armour)
            if (chosen_cannon['Type'] == 'LA'):
                result = Result(parent=ndb.Key("armour", armour), average_la = total_dmg_la/count, armour = armour)
            result.put()          
            armour += 1
        
        dmg_query = result.query().fetch(30)
        
        ndb.delete_multi(result.query().fetch(keys_only=True))
                
        armour = 12  
        roll = float(total_dmg_mc)/float(count)
        
        template_values = {
            'dmg_query': dmg_query,
            'weapon': weapon,
            'roll': roll,
        }

        template = JINJA_ENVIRONMENT.get_template('calc.html')
        self.response.write(template.render(template_values))
 
application = webapp2.WSGIApplication([
    ('/', MainPage),
    ('/calc', CalcPage),
], debug=True)